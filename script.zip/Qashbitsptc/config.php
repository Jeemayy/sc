<?php

// JANGAN MENGUBAH APAPUN SELAIN YG DIDALAM TANDA (")
// PERHATIKAN TANDA (") JANGAN SAMPAI TERHAPUS
// AGAR SCRIPT TIDAK ERROR

$user_agent = "Mozilla/5.0 (Linux; Android 11; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.92 Mobile Safari/537.36";

$cookies = 'bitmedia_fid=eyJmaWQiOiI0NzUzY2FjZjRiNDQzNTBjYmExMjA4YWQwYTgzZGQwYiIsImZpZG5vdWEiOiI2MjZmZTlhZTExN2MxYzEyNzA0NmU3OWVjZWU1NTBlNiJ9; SesHashKey=nwdwqmev4i899wsp; SesToken=ses_id%3D26342%26ses_key%3Dnwdwqmev4i899wsp; AccExist=26342; PHPSESSID=jn0rp9uhbvmvdg1hb527kafjn4; _coinzilla_fp_=%7B%22backed%22%3A%5B%7B%22cap%22%3A1%2C%22lastCall%22%3A1639319251845%7D%5D%7D';
