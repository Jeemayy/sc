========================
$ pkg update
$ pkg upgrade
$ pkg install php
$ pkg install tesseract
$ pkg install imagemagick
$ pkg install git
$ termux-setup-storage
========================
Run SC 
$ git clone https://github.com/iewilmaestro/macrobits
$ cd macrobits
$ php bot.php
========================
