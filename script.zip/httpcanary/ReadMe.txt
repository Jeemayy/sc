Android 11 NON Root Only ,Not For Any other Android Version or For Rooted Device


Instruction
_____________

1. Install HttpCanary 2.7.0 A11 apk
2. Open the HttpCanary app after install
3. Don't uninstall installed HttpCanary Then install HttpCanary 3.3.6 Fix All bug Apk over it

Certificate Install Instruction
________________________________
HttpCanary Will Not Work if CA certificate if not installed 

Certificate Come With Zip file

1. Goto setting
2. Find Credential Install option ( The option May differ with Brand But Found Mostly on Security setting)
3. in credential storage setting you find Install certificate from storage click on it
5. CA certificate install click on it
4. chose certificate Folder that you extracted from zip and select HttpCanary.pem
5. Then for VPN and App certificate choose HttpCanary.p12 file 
it will ask for Password and Name
use 

password - HttpCanary
Name - HttpCanary VPN & Apps

6. Similarly For WiFi certificate choose HttpCanary.p12 file password is same And Name should be HttpCanary WiFi