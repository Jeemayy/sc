
$bost1 = "3";
