
$bost3 = "3";
