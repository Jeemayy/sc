
$useragent = "Mozilla/5.0 (Linux; Android 11; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36";
$user = "Jeemay";
$ecID = "EC-UserId-216937";
