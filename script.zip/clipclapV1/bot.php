<?php
date_default_timezone_set("Asia/Jakarta");
//date_default_timezone_set("UTC");

error_reporting(0);
// warna
$biru="\033[1;34m";
$kuning="\033[1;33m";
$merah="\033[1;31m";
$putih="\033[1;37m";
$hijau="\033[1;32m";
$cyan="\033[1;36m";
$ungu="\033[1;35m";
$dark="\033[1;30m";
$abu = "\033[0;90m";
$abu1 = "\033[1;90m";
$merah1 = "\033[1;91m";
$end = "\033[0m";
$blockabu = "\033[100m";
$blockmerah = "\033[101m";
$blockstabilo = "\033[102m";
$blockkuning = "\033[103m";
$blockbiru = "\033[104m";
$blockpink = "\033[105m";
$blockcyan = "\033[106m";
$blockputih = "\033[107m";
$panah = $biru."▶";
/*
$headers = array();
$headers[] = "Mozilla/5.0 (Linux; Android 10; M2004J19C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.101 Mobile Safari/537.36 GSA/11.29.10.21.arm64";
$ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, "https://controlc.com/3f4665e4");
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      $res = curl_exec($ch);

$l1 = explode('Link: ',$res);
$l2 = explode(' ',$l1[1]);
$pw1 = explode('Password: ',$res);
$pw = explode(' ',$pw1[1]);

$pass = $pw[0];
$read = file_get_contents("passw");

if($pass == "up"){
echo "{$kuning1}  Script hasbeen update\n";
echo $hijau1."  link script update: ".$ungu2.$l2[0]."\n\n";
exit;
}

if ($pass == 'off'){

echo "{$merah}  script off, {$putih1}Hubngi admin untuk info update script\n";
echo"{$putih1}  Telegram: {$cyan}@Guebapakloe\n";

exit;
}else{
if($read == $pass){
}else{
$save = fopen("passw", "w");
}
}
echo"{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡\n";
echo$putih."DATE \033[1;92m".date("d.m.Y")."\033[1;97m               TIME \033[1;92m".date("H:i:s")."\n\n";
echo$green." Masukin password dulu coy buat lanjut \n";
echo$green." Link pass : ".$ungu2.$l2[0].$putih1."\n";
echo"{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡\n";
echo "{$cyan}  ➤ {$putih1}Input Password 👉 {$hijau1}";

$psw = trim(fgets(STDIN));
if($psw == $pass){
fwrite($save, $psw);
sleep(2);
echo $hijau1."  Succes login\n";
fclose($save);
sleep(1);

system("clear");
}else{
sleep(2);
echo $merah."  Invalid password\n\n";
sleep(1);
exit;
}*/
system("clear");

sleep(1);
//awal
echo $banner ="{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡\n";
echo$putih."DATE \033[1;92m".date("d.m.Y")."\033[1;97m               TIME \033[1;92m".date("H:i:s")."\n\n";
echo$cyan."Nama script".$ungu." =>".$hijau." Clipclap.apk\n"; 
echo$cyan."Creator".$ungu."     =>".$hijau." Guebapakloe\n";
echo$cyan."Thanks to".$ungu."   =>".$hijau." Pemulung, Mr. J, lord Puki\n"; 
echo$cyan."Request by".$ungu."  =>".$hijau." Pemburu lendir\n";
echo$cyan."Server".$ungu."      =>".$hijau." Online ✔\n\n";
echo$merah."Menggunakan script ini berarti\n"; 
echo$merah."semua segala resiko di tanggung sendiri\n\n";
echo"{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡\n\n";
// DATA USER

include "cfg.php";
// warna
$biru="\033[1;34m";
$kuning="\033[1;33m";
$merah="\033[1;31m";
$putih="\033[1;37m";
$hijau="\033[1;32m";
$cyan="\033[1;36m";
$ungu="\033[1;35m";
$dark="\033[1;30m";
$abu = "\033[0;90m";
$abu1 = "\033[1;90m";
$merah1 = "\033[1;91m";
$end = "\033[0m";
$blockabu = "\033[100m";
$blockmerah = "\033[101m";
$blockstabilo = "\033[102m";
$blockkuning = "\033[103m";
$blockbiru = "\033[104m";
$blockpink = "\033[105m";
$blockcyan = "\033[106m";
$blockputih = "\033[107m";


function curl(
$url,$httpheader=0,$post=0,$request=0,$proxy=0){ 
// url, httpheaders, postdata, request, proxy
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
 curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
 curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
 curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
 curl_setopt($ch, CURLOPT_TIMEOUT, 60);
 curl_setopt($ch, CURLOPT_HEADER, true);
  if($httpheader){
   curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
   }
  if($post){
   curl_setopt($ch, CURLOPT_POST, true);
   curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
   }
  if($request){
   curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $request);
   }
  if($proxy){
   curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
   curl_setopt($ch, CURLOPT_PROXY, $proxy);
   curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
   }
 $response = curl_exec($ch);
 $httpcode = curl_getinfo($ch);
  if(!$httpcode) return "Curl Error : ".curl_error($ch); else{
 $header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
 $body = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
 curl_close($ch);
 return array($header, $body);}
}

function head(){
global $device,$token,$uuid,$userid;
$ua = array();
$ua[]="Host: api.cc.lerjin.com";
$ua[]="charset: UTF-8";
$ua[]="device-type: $device_type";
$ua[]="api-version: $api_version";
$ua[]="external-version: $external_version";
$ua[]="device: $device";
$ua[]="version: 42";
$ua[]="timezone: $timezone";
$ua[]="lang: $lang";
$ua[]="token: $token";
$ua[]="uuid: $uuid";
$ua[]="app-id: ClipClaps_gg";
$ua[]="cache-control: no-cache";
$ua[]="userid: $userid";
$ua[]="content-type: application/json; charset=UTF-8";
$ua[]="user-agent: okhttp/4.2.1";
return $ua;
}

function url(){
$url="https://api.cc.lerjin.com";
return $url;
}

function user(){
global $userid,$token;
$url=url()."/user/self/info";
$data=json_encode(array("userid"=>$userid,"token"=>$token));
return json_decode(curl($url,head(),$data)[1],true);
}

// nonton
function read(){
global $userid,$token;
$url=url()."/reading/timer";
$data=json_encode(array("userid"=>$userid,"token"=>$token));
return json_decode(curl($url,head(),$data)[1],true);
}
function refresh(){
global $articletime,$videotime,$userid,$day,$token;
$url=url()."/reading/refreshTime";
$data=json_encode(array("articleTime"=>$articletime,"videoTime"=>$videotime,"userid"=>$userid,"day"=>$day,"token"=>$token));

return json_decode(curl($url,head(),$data)[1],true);
}
function reward(){
global $rewardtime,$articletime,$rewardtipe,$activeday,$videotime,$userid,$version,$day,$token;
$url=url()."/reading/obtainReward";
$data=json_encode(array("rewardTime"=>$rewardtime,"articleTime"=>$articletime,"rewardType"=>$rewardtipe,"activeDay"=>$activeday,"videoTime"=>$videotime,"specific"=>"false","userid"=>$userid,"version"=>$version,"day"=>$day,"token"=>$token));
return json_decode(curl($url,head(),$data)[1],true);
}

// buka Chests
function rewardlist(){
global $userid,$token;
$url=url()."/reward/list";
$data=json_encode(array("userid"=>$userid,"token"=>$token));
return json_decode(curl($url,head(),$data)[1],true);
}
function opencopper(){
global $copper,$userid,$token;
$url=url()."/reward/treasureChest/open";
$data=json_encode(array("type"=>$copper,"userid"=>$userid,"token"=>$token));
return json_decode(curl($url,head(),$data)[1],true);
}
function opensilver(){
global $silver,$userid,$token;
$url=url()."/reward/treasureChest/open";
$data=json_encode(array("type"=>$silver,"userid"=>$userid,"token"=>$token));
return json_decode(curl($url,head(),$data)[1],true);
}
function opengold(){
global $gold,$userid,$token;
$url=url()."/reward/treasureChest/open";
$data=json_encode(array("type"=>$gold,"userid"=>$userid,"token"=>$token));
return json_decode(curl($url,head(),$data)[1],true);
}

// spin
function megaspin(){
global $token,$userid;
$url=url()."/activity/spin";
$data=json_encode(array("spinType"=>"mega","token"=>$token,"userid"=>$userid,"_reqidx"=>1));
return json_decode(curl($url,head(),$data)[1],true);
}
function luckyspin(){
global $token,$userid,$n;
$url=url()."/activity/spin";
$data=json_encode(array("spinType"=>"lucky","token"=>$token,"userid"=>$userid,"_reqidx"=>$n));
return json_decode(curl($url,head(),$data)[1],true);
}

// Game
function urls(){
$url="https://game.cc.lerjin.com";
return $url;
}
function headgame(){
global $uuid,$userid,$tokengame;
$ua=array();
$ua[]="Host: game.cc.lerjin.com";
$ua[]="charset: UTF-8";
$ua[]="timezone: 7";
$ua[]="appver: 3.5.3";
$ua[]="apiver: 42";
$ua[]="sysver: 10";
$ua[]="ostype: android";
$ua[]="lang: in";
$ua[]="userid: $userid";
$ua[]="uuid: $uuid";
$ua[]="token: $tokengame";
$ua[]="content-type: application/json; charset=utf-8";
$ua[]="user-agent: okhttp/4.2.1";
return $ua;
}
function tokengame(){
global $token,$userid;
$url=urls()."/user/login";
$data=json_encode(array("ccToken"=>$token,"ccUserId"=>$userid));
return json_decode(curl($url,head(),$data)[1],true);
}

function aquarium(){
global $tokengame;
$url=urls()."/track/game/enterGame";
$data=json_encode(array("game"=>"AQUARIUM","token"=>$tokengame));
return json_decode(curl($url,headgame(),$data)[1],true);
}

function collectfeed(){
$url=urls()."/aquarium/v1/ysgz/collect";
$data=json_encode(array("gameId"=>10003,"_reqidx"=>9));
return json_decode(curl($url,headgame(),$data)[1],true);
}

function feed(){
$url=urls()."/aquarium/v1/fish/feed";
$data=json_encode(array("gameId"=>10003,"_reqidx"=>9));
return json_decode(curl($url,headgame(),$data)[1],true);
}

function headfish(){
global $tokengame;
$ua=array();
$ua[]="Host: game.cc.lerjin.com";
$ua[]="lang: in";
$ua[]="origin: file://";
$ua[]="accept: */*";
$ua[]="user-agent: Mozilla/5.0 (Linux; Android 10; ASUS_I003DD Build/QQ2A.200501.001.B2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/74.0.3729.186 Mobile Safari/537.36 ClipClaps/3.5.3";
$ua[]="token: $tokengame";
$ua[]="content-type: application/json";
$ua[]="x-requested-with: com.sanhe.clipclaps";
return $ua;
}

function fishlist(){
$url=urls()."/aquarium/v1/fish/list";
$data=json_encode(array("gameId"=>10003,"_reqidx"=>9));
return json_decode(curl($url,headfish(),$data)[1],true);
}

function bubblelist(){
global $id;
$url=urls()."/aquarium/v1/bubbles/list";
$data=json_encode(array("gameId"=>10003,"_reqidx"=>9));
return json_decode(curl($url,headfish(),$data)[1],true);
}

function claimbubble($id1){
$url=urls()."/aquarium/v1/bubbles/pick";
$data=json_encode(array("id"=>$id1,"gameId"=>10003,"_reqidx"=>9));
return json_decode(curl($url,headfish(),$data)[1],true);
}
$user=user();
$nama=$user["data"]["nickname"];
$coin=$user["data"]["coins"];
$cash=$user["data"]["cash"];
$paypal=$user["data"]["paypal_email"];
$chest=$user["data"]["treasureChestNum"];
echo $cyan."username ➡ ".$green."$nama"."\n";
echo $cyan."ID       ➡ ".$green."$userid"."\n";
echo $cyan."Email    ➡ ".$green."$paypal"."\n";
echo $cyan."Coins    ➡ ".$green."$coin"."\n";
echo $cyan."Cash     ➡ ".$green."$cash"."\n";
echo $cyan."Chests   ➡ ".$chest."\n";
echo"{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$putih}➡{$merah}➡{$merah}➡{$putih}➡{$merah}➡\n\n";

//Pilihan
echo $panah.$hijau."[1].$ungu Nonton Video (bukan vidio bokep) & Buka Peti (bukan peti mati)\n";
echo $panah.$hijau."[2].$ungu Mega & Lucky Spin\n";
echo $panah.$hijau."[3].$ungu Aquarium & Collect Bubble\n";
echo $panah.$hijau."[4].$ungu Jalankan Semua\n";
echo $panah.$dark."[5]. Coming Soon\n";
echo $panah.$merah."[6].$merah Keluar\n";
$menu=readline($blockabu.$panah.$kuning."Pilih Menu :".$end.$putih." ");
sleep(1);

//ramuan
system("clear");
include "cfg.php";

// warna
$biru="\033[1;34m";
$kuning="\033[1;33m";
$merah="\033[1;31m";
$putih="\033[1;37m";
$hijau="\033[1;32m";
$cyan="\033[1;36m";
$ungu="\033[1;35m";
$dark="\033[1;30m";
$abu = "\033[0;90m";
$abu1 = "\033[1;90m";
$merah1 = "\033[1;91m";
$end = "\033[0m";
$blockabu = "\033[100m";
$blockmerah = "\033[101m";
$blockstabilo = "\033[102m";
$blockkuning = "\033[103m";
$blockbiru = "\033[104m";
$blockpink = "\033[105m";
$blockcyan = "\033[106m";
$blockputih = "\033[107m";
$panah = $biru."▶";

if($menu == 1){
$i=0;
while($i+=1):
$read=read();
$day=$read["data"]["day"];
$activeday=$read["data"]["activeDay"];
$videotime=$read["data"]["videoTime"];
$articletime=$read["data"]["articleTime"];
$version=$read["data"]["config"]["version"];
$rewardtime=$read["data"]["config"]["timerReward"][$i]["time"];
$interval=$read["data"]["config"]["timerScreen"][$i]["intervalTime"];
$rewardtipe=$read["data"]["config"]["timerReward"][$i]["rewardType"];

if($rewardtipe<=null){
echo $panah.$merah."Reward Chests Sudah Habis\n";
goto chestt;
}

refresh();
$claim=reward();
$msg=$claim["msg"];
if($msg=="Success"){
echo $panah.$cyan."Sukses Claim ".$rewardtipe."\n";
}else if($msg<=null){
echo $panah.$rewardtipe.$merah." Sudah Di claim\n";
goto ulang;
}
for ($x=$interval;$x>-1;$x--){
  echo "\r                                           \r";
  echo "\r".$blockabu.$panah.$merah."Loading ".$x." Seconds".$end."\r";
 sleep(1);
}
ulang:
if($i==37){
$user=user();
$chest=$user["data"]["treasureChestNum"];
if($chest=$chest){
echo $panah.$cyan."Chests Terbaru ➡ ".$chest."\n";
}else{
echo $panah.$merah."Reward Chests Sudah Habis\n";
goto chestt;}
}

endwhile;


chestt:

// open chest
$rewardlist=rewardlist();
$copper=$rewardlist["data"]["treasureChest"][0]["type"];
$jumlahcopper=$rewardlist["data"]["treasureChest"][0]["num"];
$silver=$rewardlist["data"]["treasureChest"][1]["type"];
$jumlahsilver=$rewardlist["data"]["treasureChest"][1]["num"];
$gold=$rewardlist["data"]["treasureChest"][2]["type"];
$jumlahgold=$rewardlist["data"]["treasureChest"][2]["num"];

echo $panah.$cyan."Copper Chests\n";
while(true):
$oc=opencopper(); 
$msg=$oc["msg"];
$hadiah=$oc["data"]["rewards"][0]["type"];
$hadiahh=$oc["data"]["rewards"][0]["quantity"];
if($msg=="Success"){
echo "Hadiah ".$hadiah." ".$hadiahh."\n";
}
if ($hadiah<=null){
echo $panah.$merah."Copper Chest Habis\n";
goto silver;
}

endwhile;

silver:
echo $panah.$cyan."Silver Chests\n";
while(true):
$os=opensilver();
$msg=$os["msg"];
$hadiah=$os["data"]["rewards"][0]["type"];
$hadiahh=$os["data"]["rewards"][0]["quantity"];
$hadiah1=$os["data"]["rewards"][1]["type"];
$hadiahh1=$os["data"]["rewards"][1]["quantity"];
if($msg=="Success"){
echo "Hadiah ".$hadiah." ".$hadiahh."\n";
echo "Hadiah ".$hadiah1." ".$hadiahh1."\n";
}
if ($hadiah<=null){
echo $panah.$merah."Silver Chest Habis\n";
goto gold;
}
endwhile;


gold:
echo $panah.$cyan."Gold Chests\n";
while(true):
$og=opengold();
$msg=$og["msg"];
$hadiah1=$og["data"]["rewards"][0]["type"];
$hadiahh1=$og["data"]["rewards"][0]["quantity"];
$hadiah2=$og["data"]["rewards"][1]["type"];
$hadiahh2=$og["data"]["rewards"][1]["quantity"];
$hadiah3=$og["data"]["rewards"][2]["type"];
$hadiahh3=$og["data"]["rewards"][2]["quantity"];
$hadiah4=$og["data"]["rewards"][3]["type"];
$hadiahh4=$og["data"]["rewards"][3]["quantity"];
$hadiah5=$og["data"]["rewards"][4]["type"];
$hadiahh5=$og["data"]["rewards"][4]["quantity"];

if($msg=="Success"){
echo "Hadiah ".$hadiah1." ".$hadiahh1."\n";
echo "Hadiah ".$hadiah2." ".$hadiahh2."\n";
echo "Hadiah ".$hadiah3." ".$hadiahh3."\n";
echo "Hadiah ".$hadiah4." ".$hadiahh4."\n";
echo "Hadiah ".$hadiah5." ".$hadiahh5."\n";
}

if ($hadiah1<=null){
exit($panah.$merah."Gold Chest Habis\n");
}

endwhile;
}
if($menu == 2){

// spinn
$ms=megaspin();
$msg=$ms["msg"];
$tipe=$ms["data"]["reward"]["type"];
$jml=$ms["data"]["reward"]["quantity"];
if ($msg == "Success"){
echo $panah.$cyan."Sukses Claim ".$tipe." ".$jml." Dari Mega Spin\n";
}
if ($tipe<=null){
echo $panah.$merah."Mega Spin Sudah Di Putar\n";
}

while(true):
$n=rand(1,7);
$ls=luckyspin();
$msg=$ls["msg"];
$tipe=$ls["data"]["reward"]["type"];
$jml=$ls["data"]["reward"]["quantity"];
if ($msg == "Success"){
echo $panah.$cyan."Sukses Claim ".$tipe." ".$jml." Dari Lucky Spin\n";
}
if ($tipe<=null){
echo $panah.$merah."Lucky Spin Habis\n";
exit;}

endwhile;

}
if($menu == 3){

tokengame();
$tokengame=tokengame()["data"]["token"];
$aquarium=aquarium();
$collectfeed=collectfeed();
$oke=$collectfeed["code"];
$claimfeed=$collectfeed["data"]["count"];
if($oke=="OK"){
echo $panah.$cyan."Klaim Feed ".$claimfeed."\n";
}

while(true):
$fishlist=fishlist();
$feed=feed();
$oke=$feed["code"];
$msg=$feed["message"];
$feedcount=$feed["data"]["freeFoodCount"];
if ($oke == "OK"){
  echo $panah.$cyan."Sukses Memberi Makan, Sisa Makanan ".$feedcount."\n";

}
if($message<=null){
goto bubb;
}
endwhile;

bubb:
while(true):
$bub=bubblelist();
$id=$bub["data"][0]["id"];
$id1=$bub["data"][1]["id"];
$id2=$bub["data"][2]["id"];
$id3=$bub["data"][3]["id"];
$id4=$bub["data"][4]["id"];
$id5=$bub["data"][5]["id"];
$id6=$bub["data"][6]["id"];
$id7=$bub["data"][7]["id"];
$id8=$bub["data"][8]["id"];
$id9=$bub["data"][9]["id"];
$id10=$bub["data"][10]["id"];
$id11=$bub["data"][11]["id"];
$id12=$bub["data"][12]["id"];
$id13=$bub["data"][13]["id"];
$id14=$bub["data"][14]["id"];
$id15=$bub["data"][15]["id"];
$id16=$bub["data"][16]["id"];
$id17=$bub["data"][17]["id"];
$id18=$bub["data"][18]["id"];
$id19=$bub["data"][19]["id"];
$id20=$bub["data"][20]["id"];
$id21=$bub["data"][21]["id"];
$id22=$bub["data"][22]["id"];

if($id){
$coll= array("$id","$id1","$id2","$id3","$id4","$id5","$id6","$id7","$id8","$id9","$id10","$id11","$id12","$id13","$id14","$id15","$id16","$id17","$id18","$id19","$id20","$id21","$id22");
foreach($coll as $idn){
$klaim=claimbubble($idn);
$oke=$klaim["code"];
$collect=$klaim["data"]["count"];
if($oke=="OK"){
echo $panah.$cyan."Sukses Collect ".$collect." Bubble\n";
}
}
}elseif ($id<=null){
exit($panah.$red."Bubble Telah Habis\n");
}
endwhile;
}
if($menu == 6){
exit("Terima Kasih balik lagi besok kalo ga balik gue sumpahin jomblo😆");
}
if($menu == 5){
exit("Coming soon, klo ga males update🙄");
}
if($menu == 4 ){

// warna

$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
$i=0;
while($i+=1):
$read=read();
$day=$read["data"]["day"];
$activeday=$read["data"]["activeDay"];
$videotime=$read["data"]["videoTime"];
$articletime=$read["data"]["articleTime"];
$version=$read["data"]["config"]["version"];
$rewardtime=$read["data"]["config"]["timerReward"][$i]["time"];
$interval=$read["data"]["config"]["timerScreen"][$i]["intervalTime"];
$rewardtipe=$read["data"]["config"]["timerReward"][$i]["rewardType"];

if($rewardtipe<=null){
echo $panah.$merah."Reward Chests Sudah Habis";
goto chestt;
}

refresh();
$claim=reward();
$msg=$claim["msg"];
if($msg=="Success"){
echo $panah.$cyan."Sukses Claim ".$rewardtipe."\n";
}else if($msg<=null){
echo $panah.$rewardtipe.$merah." Sudah Di claim\n";
goto ulangs;
}
for ($x=$interval;$x>-1;$x--){
  echo "\r                                           \r";
  echo "\r".$blockabu.$panah.$putih."Loading ".$x." Seconds".$end."\r";
 sleep(1);
}
ulangs:
if($i==35){
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
echo $panah.$merah."Reward Chests Sudah Habis\n";
goto chest;
}

endwhile;

chest:

$user=user();
$chest=$user["data"]["treasureChestNum"];
echo $panah.$cyan."Chests Terbaru ~> ".$chest."\n";

// open chest

$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
$rewardlist=rewardlist();
$copper=$rewardlist["data"]["treasureChest"][0]["type"];
$jumlahcopper=$rewardlist["data"]["treasureChest"][0]["num"];
$silver=$rewardlist["data"]["treasureChest"][1]["type"];
$jumlahsilver=$rewardlist["data"]["treasureChest"][1]["num"];
$gold=$rewardlist["data"]["treasureChest"][2]["type"];
$jumlahgold=$rewardlist["data"]["treasureChest"][2]["num"];


echo $panah.$cyan."Copper Chests\n";
while(true):
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
$oc=opencopper(); 
$msg=$oc["msg"];
$hadiah=$oc["data"]["rewards"][0]["type"];
$hadiahh=$oc["data"]["rewards"][0]["quantity"];
if($msg=="Success"){
echo $panah.$cyan."Hadiah ".$hadiah." ".$hadiahh."\n";
}
if ($hadiah<=null){
echo $panah.$merah."Copper Chest Habis\n";
goto silvers;
}

endwhile;
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
silvers:
echo $panah.$cyan."Silver Chests\n";
while(true):
$os=opensilver();
$msg=$os["msg"];
$hadiah=$os["data"]["rewards"][0]["type"];
$hadiahh=$os["data"]["rewards"][0]["quantity"];
$hadiah1=$os["data"]["rewards"][1]["type"];
$hadiahh1=$os["data"]["rewards"][1]["quantity"];
if($msg=="Success"){
echo "Hadiah ".$hadiah." ".$hadiahh."\n";
echo "Hadiah ".$hadiah1." ".$hadiahh1."\n";
}
if ($hadiah<=null){
echo $panah.$merah."Silver Chest Habis\n";
goto golds;
}
endwhile;

$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
golds:
echo $panah.$cyan."Gold Chests\n";
while(true):
$og=opengold();

$msg=$og["msg"];
$oke=$og["code"];
$hadiah1=$og["data"]["rewards"][0]["type"];
$hadiahh1=$og["data"]["rewards"][0]["quantity"];
$hadiah2=$og["data"]["rewards"][1]["type"];
$hadiahh2=$og["data"]["rewards"][1]["quantity"];
$hadiah3=$og["data"]["rewards"][2]["type"];
$hadiahh3=$og["data"]["rewards"][2]["quantity"];
$hadiah4=$og["data"]["rewards"][3]["type"];
$hadiahh4=$og["data"]["rewards"][3]["quantity"];
$hadiah5=$og["data"]["rewards"][4]["type"];
$hadiahh5=$og["data"]["rewards"][4]["quantity"];

if($msg=="Success"){
echo "Hadiah ".$hadiah1." ".$hadiahh1."\n";
echo "Hadiah ".$hadiah2." ".$hadiahh2."\n";
echo "Hadiah ".$hadiah3." ".$hadiahh3."\n";
echo "Hadiah ".$hadiah4." ".$hadiahh4."\n";
echo "Hadiah ".$hadiah5." ".$hadiahh5."\n";
}

if ($oke == "161"){$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
echo $panah.$merah."Gold Chest Habis\n";
goto sp;
}

endwhile;

sp:

// spinn
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
$ms=megaspin();
$msg=$ms["msg"];
$tipe=$ms["data"]["reward"]["type"];
$jml=$ms["data"]["reward"]["quantity"];
if ($msg == "Success"){
echo $panah.$cyan."Sukses Claim ".$tipe." ".$jml." Dari Mega Spin\n";
}
if ($tipe<=null){
echo $panah.$merah."Mega Spin Sudah Di Putar\n";
goto ls;
}

ls:

while(true):
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
$n=rand(1,7);
$ls=luckyspin();
$msg=$ls["msg"];
$tipe=$ls["data"]["reward"]["type"];
$jml=$ls["data"]["reward"]["quantity"];
if ($msg == "Success"){
echo $panah.$cyan."Sukses Claim ".$tipe." ".$jml." Dari Lucky Spin\n";
}
if ($tipe<=null){
echo $panah.$merah."Lucky Spin Habis\n";
goto aqua;
}

endwhile;

aqua:
  

tokengame();
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
$tokengame=tokengame()["data"]["token"];
$aquarium=aquarium();
$collectfeed=collectfeed();
$oke=$collectfeed["code"];
$claimfeed=$collectfeed["data"]["count"];
if($oke=="OK"){
echo $panah.$cyan."Klaim Feed ".$claimfeed."\n";
}

while(true):
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";

$fishlist=fishlist();
$feed=feed();
$oke=$feed["code"];
$msg=$feed["message"];
$feedcount=$feed["data"]["freeFoodCount"];
if ($oke == "OK"){
  
echo $panah.$cyan."Sukses Memberi Makan, Sisa Makanan ".$feedcount."\n";

}
if($feedcount==0){
goto bubbb;
}
endwhile;

bubbb:
while(true):
$bub=bubblelist();
$id=$bub["data"][0]["id"];
$id1=$bub["data"][1]["id"];
$id2=$bub["data"][2]["id"];
$id3=$bub["data"][3]["id"];
$id4=$bub["data"][4]["id"];
$id5=$bub["data"][5]["id"];
$id6=$bub["data"][6]["id"];
$id7=$bub["data"][7]["id"];
$id8=$bub["data"][8]["id"];
$id9=$bub["data"][9]["id"];
$id10=$bub["data"][10]["id"];
$id11=$bub["data"][11]["id"];
$id12=$bub["data"][12]["id"];
$id13=$bub["data"][13]["id"];
$id14=$bub["data"][14]["id"];
$id15=$bub["data"][15]["id"];
$id16=$bub["data"][16]["id"];
$id17=$bub["data"][17]["id"];
$id18=$bub["data"][18]["id"];
$id19=$bub["data"][19]["id"];
$id20=$bub["data"][20]["id"];
$id21=$bub["data"][21]["id"];
$id22=$bub["data"][22]["id"];

if($id){
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
$coll= array("$id","$id1","$id2","$id3","$id4","$id5","$id6","$id7","$id8","$id9","$id10","$id11","$id12","$id13","$id14","$id15","$id16","$id17","$id18","$id19","$id20","$id21","$id22");
foreach($coll as $idn){
$klaim=claimbubble($idn);
$oke=$klaim["code"];
$collect=$klaim["data"]["count"];
if($oke=="OK"){
echo $panah.$cyan."Sukses Collect ".$collect." Bubble\n";
}
}
}elseif ($id<=null){
$cyan="\033[1;36m";
$merah="\033[1;31m";
$panah = $biru."▶";
echo $panah.$merah."Bubble Telah Di Collect Semua\n";
exit($merah."✖".$cyan." Jangan lupa besok balik lagi\n");
}
endwhile;
}

