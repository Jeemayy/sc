<?php

// JANGAN MENGUBAH APAPUN SELAIN YG DIDALAM TANDA (")
// PERHATIKAN TANDA (") JANGAN SAMPAI TERHAPUS
// AGAR SCRIPT TIDAK ERROR

$api_version = "2";
$external_version = "3.5.6";
$timezone = "7";
$device_type = "2";
$lang = "in";
$device = "11";

$userid = "43370416";
$uuid = "8b72ff4fc413c286";
$token = "MTE0Y2ZhZTktMGI0ZC00ZjhjLTlhNzItNDUyZThlZDI3ZmJl";





