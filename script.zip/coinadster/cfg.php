<?php


$cookie="_ga=GA1.2.1226149656.1639138292; bitmedia_fid=eyJmaWQiOiJlMGQ4NGExNDAxZmEwM2ZhMDQ2NGQwMDhkOWRiMDhhZiIsImZpZG5vdWEiOiJhYzgyNzNmOWMwYTBkNjMxZjc1ZmMwODNmZDNhYzE1NiJ9; _gid=GA1.2.1194861592.1639240166; PHPSESSID=d394dea56e1ece08c40591d547da177d; AccExist=203845; _gat_gtag_UA_116201299_15=1; SesHashKey=hr0ryi3vxqomujwl; SesToken=ses_id=203845&ses_key=hr0ryi3vxqomujwl";

$url_solve="https://api-secure.solvemedia.com/papi/_challenge.js?k=P7UUEs9AZZuZ1GtxoHnRsTutaLGvyb26;f=_ACPuzzleUtil.callbacks[0];l=en;t=img;s=standard;c=js,h5c,h5ct,svg,h5v,v/h264,v/webm,h5a,a/mp3,a/ogg,ua/chrome,ua/chrome96,os/android,os/android11,fwv/BcNgmg.gyzt41,jslib/jquery,htmlplus;am=urUjTMf-pbK.dJU.x.6lsg;ca=ajax;ts=1639318783;ct=1639240214;th=white;r=0.9349665970036738";

$User_Agent="Mozilla/5.0 (Linux; Android 11; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36";
?>
