<?php

//Isi USER-AGENT Sesuai Data Kalian
$user = 'Mozilla/5.0 (Linux; Android 11; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36';

//Isi COOKIE Sesuai Data Kalian
$cookie = 'PHPSESSID=g1p14n2b1180mcnfb4io76optf; address=MNPDuk7TQEpzkwwjaijFpfY1uii3Cb63Eu';

//Isi URL-SOLVEMEDIA
$url_solvemedia = 'https://api-secure.solvemedia.com/papi/_challenge.js?k=eIowA.G1TqRH5k4PHvsz4zTraZMa9-KD;f=_ACPuzzleUtil.callbacks%5B0%5D;l=en;t=img;s=standard;c=js,h5c,h5ct,svg,h5v,v/h264,v/webm,h5a,a/mp3,a/ogg,ua/chrome,ua/chrome77,os/android,os/android11,fwv/BcW2Eg.cwmm80,cms/wordpress,jslib/jquery,htmlplus;am=-4qopYz5LRn-ThTkjPktGQ;ca=script;ts=1638978167;ct=1639045156;th=white;r=0.2090368877576123';

//Isi Wallet LTC Kalian
$wallet = 'MNPDuk7TQEpzkwwjaijFpfY1uii3Cb63Eu';
