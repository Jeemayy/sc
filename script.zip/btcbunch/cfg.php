<?php

//user agent 
//Jangan Kehapus titiknya "Mozilla/5.0 (Linux; Android 11; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36";

$useragent = "Mozilla/5.0 (Linux; Android 8.0.0; G8231) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36";

//cookie anda

$cookie = "compass_uid=601c42ad-9308-4ab0-8f3c-d90907012d72;_pbjs_userid_consent_data=3524755945110770;clever-last-tracker-54448=1;bitmedia_fid=eyJmaWQiOiJiYzIxOTcyMWQ1MDRkY2YzOTQ3NWVjNGViMzA0ZGVhYiIsImZpZG5vdWEiOiJhMjY0NDgwN2Y4YzgzYTMwYmY5OTU1NjNmZjY0YTgyYSJ9;__gads=ID=850bf5206969bf6c-22dbfc315ccf0090:T=1638681920:RT=1638681920:S=ALNI_Maxp2sKWS9Lvq8pwl3IfqAGIku3hQ;_ga=GA1.1.1536892983.1638681914;___nrbi=%7B%22firstVisit%22%3A1638681915%2C%22userId%22%3A%22601c42ad-9308-4ab0-8f3c-d90907012d72%22%2C%22userVars%22%3A%5B%5D%2C%22futurePreviousVisit%22%3A1639167692%2C%22timesVisited%22%3A2%7D;cto_bundle=mJ_5uV9SS25KWlBKcm1ROE1QSlcwZVMzdHpIMHJvWDc0aGliVTJ0JTJGQmxvaWdpTFplVXdsNnpFJTJGS1U1WGJYSkhNMGZYTlFHbjRWUzZjMjkwZXlxJTJCYkslMkZvNlFBb1RZUkRucEpkeWZoWFpOTGJnSFM5d0RqQ3FxbWJnUmxnYiUyQkU2cDFNdUdXMHF1N1UlMkZRd1BmZFBJRGRTUXJsOVElM0QlM0Q;cto_bidid=HEHxpV9UQmhneGdVR3hqZ1pSY3FOVTA1OSUyQkxpOWVINzJ3d2cyUzl3MmpKQjc2dkZKWDFuSGVyUWQ5ejRMeVRlWEdkRVZyWm85VjdNaDh5dnU3ZkVwcWIxUkZyV25UazJjb2k4ejJtaXhleUxFbHA0JTNE;csrf_cookie_name=7c08bfad60d9577ee8dd5c9b6f719bd3;ci_session=5u94im97hirj89kv3mnvr3mvgnbman4k;_ga_MTE2VX5MJ9=GS1.1.1639239820.3.1.1639239820.0;__viCookieActive=true";

