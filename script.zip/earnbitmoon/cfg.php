<?php

// Isi Semua Data Dibawah Dengan Benar Ya !!!
// Perhatikan Bagaimama Admin Mengisi Datanya
// Jangan Lupa Support Creator Scriptnya

//Isi USER-AGENT Sesuai Data Kalian
$user = "Mozilla/5.0 (Linux; Android 11; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36";

//Isi Cookie Sesuai Data Kalian
$cookie = "bitmedia_fid=eyJmaWQiOiJlMGQ4NGExNDAxZmEwM2ZhMDQ2NGQwMDhkOWRiMDhhZiIsImZpZG5vdWEiOiJhYzgyNzNmOWMwYTBkNjMxZjc1ZmMwODNmZDNhYzE1NiJ9; _ga=GA1.1.627517026.1638681366; AccExist=129382; SesHashKey=jxvrf5pwm2d3p0gu; SesToken=ses_id=129382&ses_key=jxvrf5pwm2d3p0gu; PHPSESSID=eqcq754deb7m9l995pp0n4dl41; _ga_7Z81E54NN3=GS1.1.1639134110.3.0.1639134110.0";

//Isi Url-Solvemedia Sesuai Data Kalian
$url_solvemedia = "https://api-secure.solvemedia.com/papi/_challenge.js?k=5TuPjHOPoHvCPuSfsUohIl19kOkG2877;f=_ACPuzzleUtil.callbacks[0];l=en;t=img;s=standard;c=js,h5c,h5ct,svg,h5v,v/h264,v/webm,h5a,a/mp3,a/ogg,ua/chrome,ua/chrome96,os/android,os/android11,fwv/BcfU8g.pfdt34,jslib/jquery,htmlplus;am=YDFRUEOM7dVl9oQyQ4zt1Q;ca=ajax;ts=1639100567;ct=1639100679;th=white;r=0.003281747594864548";
