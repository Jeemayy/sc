<?php
$abu2="\033[1;30m";
$putih="\033[0;37m";
$putih2="\033[1;37m";
$red="\033[0;31m";
$red2="\033[1;31m";
$green="\033[0;32m";
$green2="\033[1;32m";
$yellow="\033[0;33m";
$yellow2="\033[1;33m";
$blue="\033[0;34m";
$blue2="\033[1;34m";
$purple="\033[0;35m";
$purple2="\033[1;35m";
system("clear");
error_reporting(0);
include"cfg.php";

class Ltchost{

public function wdh($coin,$cookie,$token,$track,$min_wd){

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, "https://litecoin.host/0/".$coin."/account/withdraw-post-faucetpay");
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $header=array();
  $header[]="cookie: ".$cookie;
  curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_POSTFIELDS, "_token=".$token."&track=".$track."&amount=".$min_wd);
  return curl_exec($ch);
}
public function pars($awal,$akhir,$inti,$res){
$a=explode($awal,$res);
$b=explode($akhir,$a[$inti]);
return $b[0];}
public function page($cookie,$coin){
return shell_exec("curl --silent --header 'cookie: ".$cookie."' https://litecoin.host/0/".$coin."/account/withdraw");}
public function balance($cookie,$coin){
return $this->pars('Your Balance <strong>','</strong>',2,$this->page($cookie,$coin));}
public function ngegas($cookieb,$coin,$min_wd){
if($this->balance($cookieb,$coin)>$min_wd){
$track=$this->pars(';" value="','">',1,$this->page($cookieb,$coin));
$token=$this->pars('"_token" value="','"> <div',1,$this->page($cookieb,$coin));
$withdraw=$this->wdh($coin,$cookieb,$token,$track,$min_wd);

$danger=$this->pars('<div class="alert alert-danger">','</div>',1,$withdraw);
if($danger<=null){
echo "\n\033[0;32m[\033[1;37m".$coin."\033[0;32m] Success Withdraw ".$this->balance($cookieb,$coin)." {$coin} ke faucetpay\n";
}else{
echo "\n\033[0;32m[\033[1;37m".$coin."\033[0;32m] \033[1;31m".$danger."\n";
}}
if($this->balance($cookieb,$coin)<=null){
echo "\n\033[1;31mperiksa jaringan / cookie\n";
}else{
$blc="\n\033[0;32mBalance [\033[1;37m".$coin."\033[0;32m] \033[1;37m".$this->balance($cookieb,$coin)."\n";
}
return $blc;
}}
echo $blue."\n╔══════════════════════════╗";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n║".$putih."█".$blue."╔═════╗".$putih."███████████████⊙██".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$yellow."NOKIA".$blue."║".$putih."██████████████████".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."╚═════╝".$putih."██████████████████".$blue."║".$putih2." [!] CREATOR : MRs.M4JOR.exe";
echo $blue."\n║".$putih."██████████████████████████".$blue."║".$putih2." [!] WHATSAPP : 081327753909";
echo $blue."\n║".$putih."█".$blue."╔══════════════════════╗".$putih."█".$blue."║ ".$putih2."[!] JOIN GRUP : t.me/panggilmajor";
echo $blue."\n║".$putih."█".$blue."║".$yellow."XL".$abu2."▒▒▒▒▒▒▒▒▒▒".$putih2."📶4G".$abu2."▒▒".$putih2."100%".$blue."║".$putih."█".$blue."║ ".$putih2."[#] VERSI : 1.0";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$putih2."WELCOME TO SCRIPT ".$abu2."▒▒▒▒".$blue."║".$putih."█".$blue."║".$red." [!] warning !!";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$yellow." [-] ini adalah program ilegal";
echo $blue."\n║".$putih."█".$blue."║".$putih2."BY MR.MAJOR  ".$abu2."▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$yellow." [-] https://saweria.co/Mrmajor";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$putih2."----------".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$green2." [#] SCRIPT: litecoin.host";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║".$putih." = = = = = = = = = = = = = = = =";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$abu2."▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."║".$putih2."KEMBALI".$abu2."▒▒▒▒▒▒▒▒▒▒".$putih2."PILIH".$blue."║".$putih."█".$blue."║";
echo $blue."\n║".$putih."█".$blue."╚══════════════════════╝".$putih."█".$blue."║";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n║".$putih."███▤▤▤▤▤██▧▧▧▧▧▧██▤▤▤▤▤███".$blue."║";
echo $blue."\n║".$putih."██████████████████████████".$blue."║";
echo $blue."\n╚══════════════════════════╝\n";
$new=new Ltchost();
while(true){
echo $new->ngegas($cookie_btc,"btc","0.00000010");
echo $new->ngegas($cookie_zec,"zec","0.00002000");
echo $new->ngegas($cookie_usdt,"usdt","0.00400000");
echo $new->ngegas($cookie_trx,"trx","0.05000000");
echo $new->ngegas($cookie_sol,"sol","0.00002000");
//echo $new->ngegas($cookie_ltc,"ltc","");
//echo $new->ngegas($cookie_fey,"fey","");
echo $new->ngegas($cookie_eth,"eth","0.00000100");
echo $new->ngegas($cookie_doge,"doge","0.02000000");
echo $new->ngegas($cookie_dgb,"dgb","0.10000000");
echo $new->ngegas($cookie_dash,"dash","0.00003000");
echo $new->ngegas($cookie_bnb,"bnb","0.00000800");
echo $new->ngegas($cookie_bch,"bch","0.00001000");

$tik=array("🕛","🕐","🕑","🕒","🕓","🕔","🕕","🕖","🕗","🕘","🕙","🕚");
$ti=0;
$color=["\033[0;31m","\033[0;33m","\033[0;32m","\033[0;34m","\033[0;35m"];
for($i=120; $i>=0; $i--){
echo "\r                                                               \r";
echo $putih.">".$color[rand(0,count($color)-1)]."≈≈≈≈".$putih."<".$red2." tunggu ".$putih2.$i.$putih." detik " .$tik[$ti];
sleep(1);
echo "\r                                          \r";
$ti++;
if($ti >4){
$ti=0;
}
}
echo "\r                                          \r";
}

