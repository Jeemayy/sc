<?php

//Isi USER-AGENT Sesuai Data Kalian
$user = 'XXXX';

//Isi Cookie Sesuai Data Kalian
$cookie = 'xxxx';
