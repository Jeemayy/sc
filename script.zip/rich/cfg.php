<?php

//Isi USER-AGENT Sesuai Data Kalian
$user = 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Mobile Safari/537.36';

//Isi COOKIE Sesuai Data Kalian
$cookie = 'PHPSESSID=2h27a5p3c9uusgtq7he0r5q7cv; address=0x69768c066a0fe69c11d6e0dc24802875aedc7e16; cf_use_ob=0';

//Isi URL-SOLVEMEDIA
$url_solvemedia = 'http://api.solvemedia.com/papi/_challenge.js?k=C7OHROiaCc.i4BeANuyxjJyKINSAWk-u;f=_ACPuzzleUtil.callbacks%5B0%5D;l=en;t=img;s=standard;c=js,h5c,h5ct,svg,h5v,v/h264,v/webm,h5a,a/mp3,a/ogg,ua/chrome,ua/chrome96,os/android,os/android11.537,fwv/BcKNeQ.mded91,jslib/jquery,adblk,htmlplus;am=Fy9dI3rDC78S7dLgesMLvw;ca=script;ts=1639442716;ct=1639443366;th=white;r=0.3092712796996777';

//Isi Wallet DOGE Kalian
$wallet = '0x69768c066a0fe69c11d6e0dc24802875aedc7e16';
