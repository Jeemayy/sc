<?php

$useragent="Mozilla/5.0 (Linux; Android 11; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36";

$cookie='_ga=GA1.1.1502893043.1638681658; __gads=ID=67e55bde1a519258-22fec6a957cf00b4:T=1638681658:RT=1638681658:S=ALNI_MZq9xq_5-hz3O5mV-hB_UKEDsTBRQ; csrf_cookie_name=f3c04c1ef6273376bfe1f5a2cd8429a2; AdskeeperStorage={"0":{},"C1112699":{"page":1,"time":1639138484747}}; _data_cpc=1-1_15-1_201-1; a=VyrxzoOGoeHvMAeycW08MIXfGwgXJCw3; _data_pop=312-1; ci_session=63c4ef23c5dca2d831df959f51e4d4260e56a096; token_QpUJAAAAAAAAGu98Hdz1l_lcSZ2rY60Ajjk9U1c=BAYAYbNE0gFhs020gAGBAsAAIDBr1IxFLSz6NRW3jSYLD0Ujbxq3lQwwOm49wIwVdT37wQBHMEUCIG07ZyZyfHZDPcNitef23NB4K00Pz61zVLwbuVkqYFyhAiEA09RLErDzw9jzold2-pyHEmzmg1zsEMqeaxtvbGGNpe4; _ga_JGR00C6TTS=GS1.1.1639138460.2.1.1639140788.0';

//url solve gak usah di oprek kalo gak ngerti
$url_solve="https://api-secure.solvemedia.com/papi/_challenge.js?k=cctcvxndzWsDx8UEcmK0R-OB6VML3JZk;f=_ACPuzzleUtil.callbacks[0];l=en;t=img;s=standard;c=js,h5c,h5ct,svg,h5v,v/h264,v/webm,h5a,a/mp3,a/ogg,ua/chrome,ua/chrome96,os/android,os/android11,fwv/BcYgWg.pqhe55,htmlplus;am=FJtMrymhP-QRXWxtKaE.5A;ca=script;ts=1639138367;ct=1639138471;th=white;r=0.7909075468935212";

?>