<?php

date_default_timezone_set("Asia/Jakarta");
//Color
    $green = "\e[1;32m";
    $blue = "\e[1;34m";
    $red = "\e[1;31m";
    $white = "\33[37;1m";
    $yellow = "\e[1;33m";
    $cyan = "\e[1;36m";
    $purple = "\e[1;35m";
    $gray = "\e[1;30m";  

        include("cfg.php");
    system('clear');
    sleep(2);

function pembukaan(){
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m"; 
system('clear');
echo$cyan."Welcome to my script\n";
echo$red."Jangan lupa rokok 🚬 sama kopi nya ☕\n";

sleep(4);
system('clear');
}

function strip(){
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
echo$red." ≠".$green."==".$blue."==".$white."==".$yellow."==".$cyan."==".$purple."==".$gray."==".$red."==".$green."==".$blue."==".$white."==".$yellow."==".$cyan."==".$purple."==".$gray."==".$red."==".$green."==".$blue."==".$white."==".$yellow."==".$cyan."==".$purple."==".$gray."==".$green."==".$red."≠\n";
}

function sruput(){
$yellow = "\e[1;33m";
$white = "\33[37;1m";
echo$white." Name Script    : ".$yellow."https://freemining.cloud\n";
echo$white." Script ver.    : ".$yellow."1.0\n";
echo$white." Coded by       : ".$yellow."Guebapakloe\n";
echo$white." My Partner     : ".$yellow."koecheng oren teams\n";
echo$white." Thank For      : ".$yellow."Allah S.W.T\n";
echo$white." Supported by   : ".$yellow."Captain Bulls\n";
}

function note(){
$cyan = "\e[1;36m";
echo$cyan." 👉 This Script Free Don't Sell❗\n";
echo$cyan." 👉 No password  ❗\n";
echo$cyan." 👉 No encode \n";
echo$cyan." 👉 No bacot, tinggal comot \n";
}

error_reporting(0);

pembukaan();
strip();
sruput();
strip();
note();
strip();

//TRX(1)
$header = array();
$header[] = "user-agent:".$useragent;
$header[] = "cookie:".$cookie;
    $ch = curl_init(); 
	curl_setopt($ch, CURLOPT_URL, "https://freetronmining.cloud/account/dashboard");
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_ENCODING, "");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$dash = curl_exec($ch);
$bal1 = explode('user-balance">', $dash)[1];
$bal2 = explode('<small class=', $bal1)[0];

//Doge(2)
$header = array();
$header[] = "user-agent:".$useragent;
$header[] = "cookie:".$cookie2;
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "https://freedogecoin.cloud/account/dashboard");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_ENCODING, "");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$dash = curl_exec($ch);
$bal3 = explode('user-balance">', $dash)[1];
$bal4 = explode('<small class=', $bal3)[0];

//Balance
echo$cyan." TRX balance : ".$green.$bal2."\n";
echo$cyan." Doge Balance : ".$green.$bal4."\n";

strip();
sleep(1);
//mulai perulangan
while(true){
//auto
$header = array();
$header[] = "user-agent:".$useragent;
$header[] = "cookie:".$cookie;

    $ch = curl_init(); 
	curl_setopt($ch, CURLOPT_URL, "https://freetronmining.cloud/account/dashboard");
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_ENCODING, "");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$dash = curl_exec($ch);
$bal1 = explode('user-balance">', $dash)[1];
$bal2 = explode('<small class=', $bal1)[0];

//Doge(2)
$header = array();
$header[] = "user-agent:".$useragent;
$header[] = "cookie:".$cookie2;
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "https://freedogecoin.cloud/account/dashboard");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_ENCODING, "");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$dash = curl_exec($ch);
$bal3 = explode('user-balance">', $dash)[1];
$bal4 = explode('<small class=', $bal3)[0];

echo$blue." New jobs from Gue babeh loe \n";
sleep(1);
echo$red." Balance TRX  ➡".$purple."  $bal2\n";
echo$green." Balance Doge ➡".$purple."  $bal4\n";
strip();
for($x=240;$x>0;$x--){
echo "\r \r";
echo$green." Sabar coy lagi mining ⛏⛏ ".$red."[".$yellow.$x.$red."] ".$green."seconds ⏳";
echo "\r \r";
sleep(1);
}
}