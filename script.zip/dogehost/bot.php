<?php
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
error_reporting(0);
include('cfg.php');
system('clear');
sleep(2);


function Get($url, $ua){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
sleep(1);
}

function Post($url, $ua, $data){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_COOKIEJAR, "./cookie/cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "./cookie/cookie.txt");
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}

echo$cyan." Auto Minings Start...\n";
echo$cyan."Target web : ".$red." Kepo luh jing \n";
echo$green."■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n";

while(true){
$url = "https://litecoin.host/0/doge/account/withdraw";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$pyl = Get($url, $ua);
$one = explode('Your Balance <strong>',$pyl);
$two = explode('</strong>',$one[1]);
$wdal = "$two[0]";
$jam=date("H:i:s");

echo$red."【".$yellow.$jam.$red."】{$white}Update Mining Balance : ".$cyan.$wdal." {$red}DOGE\n";
echo$gray." ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ \n";


for($x=180;$x>0;$x--){echo "\r \r";
echo$gray." Please wait ".$red."[".$yellow.$x.$red."] ".$gray."seconds ⏳";
echo "\r \r";
sleep(1);}


if($wdal > $min_wd){

$url = "https://litecoin.host/0/doge/account/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$dl = Get($url, $ua);

$url = "https://litecoin.host/0/doge/account/withdraw";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$pyl = Get($url, $ua);
$one1 = explode('<option style="background: black;" value="',$pyl);
$two2 = explode('">',$one1[1]);
$trl = "$two2[0]";
$one3 = explode('Your Balance <strong>',$pyl);
$two4 = explode('</strong>',$one3[1]);
$wdal = "$two4[0]";
$one5 = explode('name="_token" value="',$pyl);
$two6 = explode('">',$one5[1]);
$tkl = "$two6[0]";

$link = "https://litecoin.host/0/doge/account/withdraw-post-faucetpay";
$data = "_token=".$tkl."&track=".$trl."&amount=".$wdal;
$cfg = Post($link, $ua, $data);
$one7 = explode('Redirecting to <a href="https://litecoin.host/0/doge/account/withdraw?m=',$cfg);
$two8 = explode('">',$one[1]);
$msg0 = "$two8[0]";
$msg = trim(str_replace(" ","%20",$msg0));

$url = "https://litecoin.host/0/doge/account/withdraw?m=".$msg;
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$wwl = Get($url, $ua);
$jam=date("H:i:s");

echo$red."【".$yellow.$jam.$red."】".$green.$wdal." DOGE sent to your ".$cyan."Faucet".$blue."Pay".$green." account\n";


}else{
echo$yellow."\r Collecting DOGE...                  \r";
sleep(3);
}}